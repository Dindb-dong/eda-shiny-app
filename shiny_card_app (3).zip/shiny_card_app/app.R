# =====================================================================
#  Card Spending in Korea and Taiwan — Shiny app (EDA Final Project)
#  - Put these 3 CSV files in the same folder and run:  shiny::runApp()
#      korea_en_on_off.csv / taiwan_all_en_on_off.csv / korea_taiwan_cpi_monthly.csv
#  - Exchange rates (fx_monthly.csv) are downloaded from FRED (EXKOUS, EXTAUS,
#    monthly averages) on first run. Without internet, supply the file yourself:
#      columns: date,krw_per_usd,ntd_per_usd   (date like 2014-01-01)
# =====================================================================

library(shiny)
library(dplyr)
library(tidyr)
library(ggplot2)
library(scales)

# ---------------------------------------------------------------------
# 0. Settings
# ---------------------------------------------------------------------
f_kr  <- "korea_en_on_off.csv"
f_tw  <- "taiwan_all_en_on_off.csv"
f_cpi <- "korea_taiwan_cpi_monthly.csv"
f_fx  <- "fx_monthly.csv"

# Category labels (edit names here if needed)
cat_labels <- c(
  FD = "Food (FD)",
  CT = "Clothing (CT)",
  LG = "Housing & lodging (LG)",
  TR = "Transport (TR)",
  EE = "Education & entertainment (EE)",
  DP = "Department stores (DP)",
  OT = "Other (OT)",
  EC = "E-commerce (EC)"
)

country_cols <- c("Korea" = "#2a78d6", "Taiwan" = "#eb6834")

# ---------------------------------------------------------------------
# 1. Data
# ---------------------------------------------------------------------
# Korea: 7 offline categories + EC already in separate rows
kr <- read.csv(f_kr, stringsAsFactors = FALSE) %>%
  transmute(date     = as.Date(date),
            country  = "Korea",
            category = category,
            origin   = category,                 # original category (for "exclude Other")
            amount   = as.numeric(total_amount_krw))

# Taiwan: offline amount per category = 7 categories,
#         online amounts summed across categories = 8th category EC
tw_raw <- read.csv(f_tw, stringsAsFactors = FALSE)
tw_off <- tw_raw %>%
  transmute(date = as.Date(date), country = "Taiwan",
            category = category, origin = category,
            amount = as.numeric(offline_amount_ntd))
tw_on <- tw_raw %>%
  transmute(date = as.Date(date), country = "Taiwan",
            category = "EC", origin = category,
            amount = as.numeric(online_amount_ntd))

card <- bind_rows(kr, tw_off, tw_on)

# CPI (2020 = 100 columns)
cpi_raw <- read.csv(f_cpi, fileEncoding = "UTF-8-BOM", check.names = FALSE,
                    stringsAsFactors = FALSE)
names(cpi_raw)[1:3] <- c("ym", "TW", "KR")
cpi <- cpi_raw %>%
  filter(!is.na(ym), ym != "") %>%
  transmute(date = as.Date(paste0(ym, "-01")), KR = as.numeric(KR), TW = as.numeric(TW)) %>%
  pivot_longer(c(KR, TW), names_to = "cc", values_to = "cpi") %>%
  mutate(country = ifelse(cc == "KR", "Korea", "Taiwan")) %>%
  select(date, country, cpi) %>%
  filter(!is.na(cpi))

# Exchange rates (local currency per 1 USD, monthly average)
load_fx <- function() {
  if (!file.exists(f_fx)) {
    get_fred <- function(id) {
      x <- read.csv(paste0("https://fred.stlouisfed.org/graph/fredgraph.csv?id=", id),
                    stringsAsFactors = FALSE)
      names(x) <- c("date", "rate")
      data.frame(date = as.Date(x$date),
                 rate = suppressWarnings(as.numeric(x$rate)))
    }
    fx_wide <- tryCatch({
      k <- get_fred("EXKOUS"); t <- get_fred("EXTAUS")
      inner_join(rename(k, krw_per_usd = rate), rename(t, ntd_per_usd = rate), by = "date") %>%
        filter(date >= as.Date("2013-01-01"))
    }, error = function(e) NULL)
    if (is.null(fx_wide)) return(NULL)
    write.csv(fx_wide, f_fx, row.names = FALSE)
  }
  fx_wide <- read.csv(f_fx, stringsAsFactors = FALSE)
  fx_wide$date <- as.Date(fx_wide$date)
  bind_rows(
    data.frame(date = fx_wide$date, country = "Korea",  rate = fx_wide$krw_per_usd),
    data.frame(date = fx_wide$date, country = "Taiwan", rate = fx_wide$ntd_per_usd)
  ) %>% filter(!is.na(rate))
}
fx <- load_fx()
if (is.null(fx)) fx <- data.frame(date = as.Date(character()), country = character(), rate = numeric())
fx_ok <- nrow(fx) > 0

# Common window: 2014-01 to whichever ends first (Korea card data, CPI)
start_date <- as.Date("2014-01-01")
end_date   <- min(max(kr$date), max(cpi$date))

# Country-specific peak restriction periods (optional overlay)
strict_df <- data.frame(
  country = c("Korea", "Taiwan"),
  xmin = as.Date(c("2021-07-01", "2021-05-01")),
  xmax = as.Date(c("2021-10-31", "2021-07-31"))
)

# ---------------------------------------------------------------------
# 2. Styles (white page, near-black text, gray rules, no tinted surfaces)
# ---------------------------------------------------------------------
chevron_svg <- paste0(
  "data:image/svg+xml;charset=UTF-8,",
  "%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E",
  "%3Cpath d='M1 1.5l5 5 5-5' fill='none' stroke='%23111' stroke-width='1.5'/%3E%3C/svg%3E"
)

app_css <- paste0("
:root { --ink:#111; --muted:#555; --rule:#d9d9d9; }
html, body { background:#fff; color:var(--ink); }
body, button, input, select, label, .control-label, .nav, .subtabs {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
}
h1, h2, h3, h4 { font-family: Georgia, 'Times New Roman', serif; font-weight:normal; color:var(--ink); }
h1 { font-size:28px; margin:0 0 4px; }
h2 { font-size:20px; margin:28px 0 10px; }
.lede { color:var(--muted); margin:0 0 16px; }

/* Layout: menu at left, content at right; menu stacks above on mobile */
.app { display:grid; grid-template-columns:200px minmax(0,1fr); gap:40px;
       max-width:1440px; margin:0 auto; padding:28px 24px 48px; }
@media (max-width:767px) { .app { grid-template-columns:1fr; gap:16px; padding:16px; } }

.side-menu { border-right:1px solid var(--rule); padding-right:16px; }
@media (max-width:767px) { .side-menu { border-right:0; border-bottom:1px solid var(--rule); padding:0 0 12px; } }
.side-menu .menu-title { font-size:12px; text-transform:uppercase; letter-spacing:.06em; color:var(--muted); margin:0 0 8px; }
.side-menu ul { list-style:none; margin:0; padding:0; }
.side-menu a { display:block; padding:6px 12px; color:var(--ink); text-decoration:none;
               border-left:2px solid transparent; }
.side-menu a[aria-current='page'] { border-left-color:var(--ink); }

/* Current subtab: underline */
.subtabs { display:flex; gap:24px; border-bottom:1px solid var(--rule); margin:0 0 20px; }
.subtabs a { padding:8px 0; color:var(--ink); text-decoration:none; border-bottom:2px solid transparent; margin-bottom:-1px; }
.subtabs a[aria-current='page'] { border-bottom-color:var(--ink); }

/* Filters: 4 columns wide, 2 intermediate, 1 narrow */
.filters { display:grid; grid-template-columns:repeat(4, minmax(0,1fr)); gap:12px 28px;
           border-top:1px solid var(--rule); border-bottom:1px solid var(--rule); padding:16px 0; }
@media (max-width:1199px) { .filters { grid-template-columns:repeat(2, minmax(0,1fr)); } }
@media (max-width:599px)  { .filters { grid-template-columns:1fr; } }
.filters .form-group, .filters .shiny-input-container { width:100% !important; margin-bottom:4px; }
.filters .control-label { font-weight:600; font-size:13px; }
.filters .checkbox { margin-bottom:2px; }
.filters .help-block, .note { color:var(--muted); font-size:12.5px; margin:0 0 12px; }

/* Native select: decorative chevron, 13px inset */
.filters select, select.form-control {
  -webkit-appearance:none; -moz-appearance:none; appearance:none;
  width:100%; height:auto; padding:7px 38px 7px 10px;
  background:#fff url(\"", chevron_svg, "\") no-repeat right 13px center / 12px 8px !important;
  border:1px solid #8a8a8a; border-radius:2px; box-shadow:none; color:var(--ink);
}

/* Neutral slider and buttons */
.irs--shiny .irs-bar { background:var(--ink); border-color:var(--ink); }
.irs--shiny .irs-from, .irs--shiny .irs-to, .irs--shiny .irs-single { background:var(--ink); }
.irs--shiny .irs-handle { border-color:var(--ink); }
.btn-default { background:#fff; color:var(--ink); border:1px solid var(--ink); border-radius:2px; }
.btn-default:hover { background:#fff; text-decoration:underline; }

/* Keyboard focus */
a:focus-visible, button:focus-visible, select:focus-visible, input:focus-visible,
.btn:focus-visible { outline:2px solid var(--ink); outline-offset:2px; }

#hover_info { background:#fff; border:0; border-left:2px solid var(--rule); border-radius:0;
              font-family:inherit; font-size:13px; padding:4px 10px; min-height:28px; }
")

native_select <- function(id, label, choices, selected = NULL) {
  selectInput(id, label, choices = choices, selected = selected, selectize = FALSE)
}

# ---------------------------------------------------------------------
# 3. UI (single tab)
# ---------------------------------------------------------------------
ui <- fluidPage(
  title = "Card Spending in Korea and Taiwan",
  lang = "en",
  tags$head(tags$style(HTML(app_css)),
            tags$meta(name = "viewport", content = "width=device-width, initial-scale=1")),

  div(class = "app",
    tags$nav(class = "side-menu", `aria-label` = "Sections",
      p(class = "menu-title", "EDA Final Project"),
      tags$ul(tags$li(tags$a(href = "#main", `aria-current` = "page", "Card spending")))
    ),

    tags$main(id = "main",
      h1("COVID-19 and Card Spending: Korea and Taiwan"),
      p(class = "lede", "Monthly card spending, January 2014 to August 2023"),

      tags$nav(class = "subtabs", `aria-label` = "Subtabs",
        tags$a(href = "#trend", `aria-current` = "page", "Spending trends")),

      tags$section(class = "filters", `aria-label` = "Filters",
        div(
          native_select("unit", "Amount shown as", c(
            "Local currency (KRW, NT$)"                    = "local",
            "US dollars (monthly exchange rate)"           = "usd",
            "Index (2014 average = 100)"                   = "index",
            "Inflation-adjusted index (2014 average = 100)" = "real_index"),
            selected = "real_index"),
          helpText(textOutput("unit_help", inline = TRUE)),
          native_select("trans", "Series", c(
            "Monthly values"                 = "raw",
            "12-month moving average"        = "ma12",
            "Year-over-year change (%)"      = "yoy")),
          helpText(textOutput("trans_help", inline = TRUE))
        ),
        div(
          native_select("scope", "Compare",
            c("Total spending" = "total", "Selected categories" = "category")),
          helpText("Total of all categories, or a separate panel for each chosen category."),
          conditionalPanel("input.scope == 'category'",
            checkboxGroupInput("cats", "Categories",
              choices = setNames(names(cat_labels), cat_labels),
              selected = c("FD", "TR", "EC")),
            helpText("E-commerce is online spending; the other categories are offline only."))
        ),
        div(
          checkboxInput("shade", "Shade the COVID-19 period", value = TRUE),
          helpText("Adds a gray band over the period set below."),
          conditionalPanel("input.shade",
            dateRangeInput("covid_range", "COVID-19 period",
              start = "2020-01-01", end = "2022-12-31",
              min = start_date, max = end_date, format = "yyyy-mm", separator = "to"),
            helpText("Start and end months of the shaded band."),
            checkboxInput("strict", "Mark peak restriction periods", value = FALSE),
            helpText("Korea: level-4 distancing, Jul–Oct 2021. Taiwan: level-3 alert, May–Jul 2021."))
        ),
        div(
          checkboxInput("drop_ot", "Exclude Other (OT)", value = FALSE),
          helpText("Removes Taiwan's May/June spikes, likely income-tax payments by card."),
          conditionalPanel(
            "input.unit == 'index' || input.unit == 'real_index' || input.unit == 'usd' || input.trans == 'yoy'",
            checkboxInput("free_y", "Separate y-axis per panel", value = FALSE),
            helpText("Lets each category panel use its own scale.")),
          sliderInput("range", "Date range", min = start_date, max = end_date,
                      value = c(start_date, end_date), timeFormat = "%Y-%m", width = "100%"),
          helpText("Months shown on the chart.")
        )
      ),

      tags$section(id = "trend", `aria-labelledby` = "trend-h",
        h2(id = "trend-h", textOutput("chart_title", inline = TRUE)),
        plotOutput("plot", height = "auto",
                   hover = hoverOpts("hov", delay = 80, delayType = "throttle")),
        div(`aria-live` = "polite", verbatimTextOutput("hover_info")),
        div(class = "note", uiOutput("note"))
      )
    )
  )
)

# ---------------------------------------------------------------------
# 4. Server
# ---------------------------------------------------------------------
server <- function(input, output, session) {

  # (1) Aggregate: total or by category
  base_data <- reactive({
    d <- card
    if (isTRUE(input$drop_ot)) d <- filter(d, origin != "OT")

    if (input$scope == "total") {
      d <- d %>%
        group_by(date, country) %>%
        summarise(amount = sum(amount, na.rm = TRUE), .groups = "drop") %>%
        mutate(panel = factor("Total spending"))
    } else {
      validate(need(length(input$cats) > 0, "Select at least one category."))
      keep <- intersect(names(cat_labels), input$cats)
      d <- d %>%
        filter(category %in% keep) %>%
        group_by(date, country, category) %>%
        summarise(amount = sum(amount, na.rm = TRUE), .groups = "drop") %>%
        mutate(panel = factor(cat_labels[category], levels = cat_labels[keep])) %>%
        select(-category)
    }
    d %>% filter(date >= start_date, date <= end_date)
  })

  # (2) Amount shown as (computed on the full window so the 2014 base and lags hold)
  unit_data <- reactive({
    u <- input$unit
    if (u == "usd") validate(need(fx_ok,
      "Exchange rates could not be loaded. Check the internet connection or add fx_monthly.csv."))

    d <- base_data() %>%
      left_join(cpi, by = c("date", "country")) %>%
      left_join(fx,  by = c("date", "country")) %>%
      mutate(div  = ifelse(country == "Korea", 1e12, 1e9),   # KRW trillion / NT$ billion
             real = amount / cpi * 100)

    # base = 2014 monthly average of each country x panel (cancels seasonality)
    idx <- function(x, date) x / mean(x[format(date, "%Y") == "2014"], na.rm = TRUE) * 100

    d <- switch(u,
      index      = d %>% group_by(country, panel) %>% mutate(value = idx(amount, date)) %>% ungroup(),
      real_index = d %>% group_by(country, panel) %>% mutate(value = idx(real, date)) %>% ungroup(),
      usd        = mutate(d, value = amount / rate / 1e9),
      local      = mutate(d, value = amount / div)
    )
    d %>% filter(!is.na(value))
  })

  # (3) Series treatment + date range
  plot_data <- reactive({
    d <- unit_data() %>% arrange(country, panel, date) %>% group_by(country, panel)
    d <- switch(input$trans,
      raw  = mutate(d, v = value),
      ma12 = mutate(d, v = as.numeric(stats::filter(value, rep(1 / 12, 12), sides = 1))),
      yoy  = mutate(d, v = (value / dplyr::lag(value, 12) - 1) * 100)
    )
    d %>% ungroup() %>%
      filter(!is.na(v), date >= input$range[1], date <= input$range[2])
  })

  comparable <- reactive({
    input$unit %in% c("index", "real_index", "usd") || input$trans == "yoy"
  })

  # Stack facets when the plot area is narrow
  n_cols <- reactive({
    w <- session$clientData$output_plot_width
    n_panel <- length(unique(plot_data()$panel))
    if (is.null(w)) w <- 1000
    if (w < 720) 1 else if (comparable() && n_panel == 1) 1 else 2
  })
  n_facets <- reactive({
    n_panel <- length(unique(plot_data()$panel))
    if (comparable()) n_panel else n_panel * 2
  })
  plot_height <- reactive({
    rows <- ceiling(n_facets() / n_cols())
    per  <- if (n_cols() == 1 && n_facets() == 1) 460 else 300
    120 + per * rows
  })

  y_label <- reactive({
    if (input$trans == "yoy") return("Year-over-year change (%)")
    lab <- switch(input$unit,
      index      = "Index, 2014 average = 100",
      real_index = "Inflation-adjusted index, 2014 average = 100",
      usd        = "USD billion",
      local      = "Korea: KRW trillion / Taiwan: NT$ billion")
    if (input$trans == "ma12") paste0(lab, ", 12-month moving average") else lab
  })

  output$unit_help <- renderText({
    switch(input$unit,
      local      = "Raw amounts; currencies differ, so each country gets its own panel.",
      usd        = "Converted at each month's exchange rate; use it to compare size.",
      index      = "Each month relative to the 2014 monthly average (= 100); prices not adjusted.",
      real_index = "Each month relative to the 2014 monthly average (= 100), with price increases removed using CPI.")
  })

  output$trans_help <- renderText({
    switch(input$trans,
      raw  = "Each month as recorded, including seasonal swings.",
      ma12 = "Average of the last 12 months; smooths seasonality but lags shocks.",
      yoy  = "Change from the same month a year earlier; removes seasonality.")
  })

  output$chart_title <- renderText({
    paste0(if (input$scope == "total") "Total card spending" else "Card spending by category",
           " · ", y_label())
  })

  output$plot <- renderPlot({
    d <- plot_data()
    validate(need(nrow(d) > 0, "No data to show."))

    last_pts <- d %>% group_by(country, panel) %>% filter(date == max(date)) %>% ungroup()
    pts      <- d %>% filter(format(date, "%m") %in% c("01", "07"))   # a marker every 6 months

    p <- ggplot(d, aes(date, v, color = country, shape = country))

    if (isTRUE(input$shade)) {
      covid_df <- data.frame(xmin = as.Date(input$covid_range[1]),
                             xmax = as.Date(input$covid_range[2]))
      p <- p + geom_rect(data = covid_df,
                         aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf),
                         inherit.aes = FALSE, fill = "grey60", alpha = 0.14)
      if (isTRUE(input$strict)) {
        p <- p + geom_rect(data = strict_df,
                           aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf, fill = country),
                           inherit.aes = FALSE, alpha = 0.16) +
          scale_fill_manual(values = country_cols, guide = "none")
      }
    }

    ref <- if (input$trans == "yoy") 0 else if (input$unit %in% c("index", "real_index")) 100 else NA
    if (!is.na(ref)) p <- p + geom_hline(yintercept = ref, linetype = "dashed", color = "grey45")

    p <- p +
      geom_line(linewidth = 0.7) +
      geom_point(data = pts, size = 2.4, stroke = 0) +
      geom_text(data = last_pts, aes(label = country), hjust = -0.2, size = 3.6,
                color = "#111111", show.legend = FALSE) +
      scale_color_manual(values = country_cols, name = NULL) +
      scale_shape_manual(values = c("Korea" = 16, "Taiwan" = 17), name = NULL) +  # blue circles, orange triangles
      scale_x_date(date_breaks = if (n_cols() == 1) "2 years" else "1 year", date_labels = "%Y",
                   expand = expansion(mult = c(0.01, 0.09))) +
      scale_y_continuous(labels = label_comma()) +
      labs(x = NULL, y = y_label()) +
      theme_minimal(base_size = 13) +
      theme(plot.background  = element_rect(fill = "white", color = NA),
            text             = element_text(color = "#111111"),
            axis.text        = element_text(color = "#444444"),
            legend.position  = "top", legend.justification = "left",
            panel.grid.minor = element_blank(),
            panel.grid.major = element_line(color = "#e6e6e6", linewidth = 0.3),
            strip.text       = element_text(face = "bold", size = 12, hjust = 0),
            axis.text.x      = element_text(angle = 45, hjust = 1))

    if (comparable()) {
      p <- p + facet_wrap(vars(panel), ncol = n_cols(),
                          scales = if (isTRUE(input$free_y)) "free_y" else "fixed")
    } else {
      # Different currencies: one panel per country instead of a dual y-axis
      p <- p + facet_wrap(vars(panel, country), ncol = n_cols(), scales = "free_y",
                          labeller = labeller(.multi_line = FALSE))
    }
    p
  },
  height = function() plot_height(),
  alt = function() {
    paste0("Line chart of monthly card spending in Korea (blue line, circle markers) ",
           "and Taiwan (orange line, triangle markers). ", y_label(), ". ",
           if (isTRUE(input$shade)) "The gray band marks the COVID-19 period. " else "",
           "Hover over the chart to read individual values.")
  })

  output$hover_info <- renderText({
    msg <- "Hover over the chart to see values."
    if (is.null(input$hov)) return(msg)
    np <- nearPoints(plot_data(), input$hov, xvar = "date", yvar = "v",
                     threshold = 12, maxpoints = 2)
    if (nrow(np) == 0) return(msg)
    paste0(format(np$date, "%Y-%m"), "  ", np$country, "  ", np$panel, "  ",
           formatC(np$v, format = "f", digits = 2, big.mark = ","), collapse = "\n")
  })

  output$note <- renderUI({
    msg <- c(
      sprintf("Common period: %s to %s (the last month with both Korean card data and CPI).",
              format(start_date, "%Y-%m"), format(end_date, "%Y-%m")),
      "E-commerce: Korea's EC category; for Taiwan, the sum of online spending across the 7 categories. Other categories are offline only.",
      if (!comparable()) "Currencies differ, so each country has its own panel. Choose an index or US dollars to compare on one axis." else NULL,
      if (input$unit == "usd") "Exchange rates: FRED EXKOUS (KRW per USD) and EXTAUS (NT$ per USD), monthly averages." else NULL
    )
    HTML(paste(msg, collapse = "<br>"))
  })
}

shinyApp(ui, server)
